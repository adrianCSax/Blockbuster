<?php
declare(strict_types=1);

namespace Dwes\ProyectoVideoClub\Util;

class SoporteYaAlquiladoException extends VideoClubException{

}