<?php
declare(strict_types=1);

namespace Dwes\ProyectoVideoClub\Util;
use \Exception;

class VideoClubException extends Exception{
    
}