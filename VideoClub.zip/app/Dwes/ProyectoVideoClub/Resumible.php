<?php

namespace Dwes\ProyectoVideoClub;

interface Resumible {
    public function mostrarResumen() : void;
}